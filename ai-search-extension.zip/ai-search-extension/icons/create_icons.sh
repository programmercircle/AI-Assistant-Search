#!/bin/bash
# Simple SVG-based icons for the extension

# Create 16x16 icon
convert -size 16x16 xc:none -fill "#6B4FBB" -draw "roundrectangle 0,0 16,16 3,3" \
  -fill white -pointsize 10 -gravity center -annotate +0+0 "AI" icon16.png 2>/dev/null || \
  echo "ImageMagick not available, creating placeholder files"

# Create 48x48 icon
convert -size 48x48 xc:none -fill "#6B4FBB" -draw "roundrectangle 0,0 48,48 8,8" \
  -fill white -pointsize 24 -gravity center -annotate +0+0 "AI" icon48.png 2>/dev/null

# Create 128x128 icon
convert -size 128x128 xc:none -fill "#6B4FBB" -draw "roundrectangle 0,0 128,128 20,20" \
  -fill white -pointsize 64 -gravity center -annotate +0+0 "AI" icon128.png 2>/dev/null

# If ImageMagick failed, create simple placeholder PNGs
if [ ! -f icon16.png ]; then
  # Create minimal valid PNG files
  python3 << 'PYTHON'
from PIL import Image, ImageDraw, ImageFont

def create_icon(size, filename):
    img = Image.new('RGBA', (size, size), (107, 79, 187, 255))
    draw = ImageDraw.Draw(img)
    
    # Draw white text "AI"
    font_size = size // 3
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
    except:
        font = ImageFont.load_default()
    
    text = "AI"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    position = ((size - text_width) // 2, (size - text_height) // 2 - bbox[1])
    draw.text(position, text, fill=(255, 255, 255, 255), font=font)
    
    img.save(filename)

create_icon(16, 'icon16.png')
create_icon(48, 'icon48.png')
create_icon(128, 'icon128.png')
PYTHON
fi
